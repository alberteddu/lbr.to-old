Sorry, the game was too big to put on github.
So you can download it from here: https://www.dropbox.com/s/ecqnhjns97bva7d/game.zip?dl=1
